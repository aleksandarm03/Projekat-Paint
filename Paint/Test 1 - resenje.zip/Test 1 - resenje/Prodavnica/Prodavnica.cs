﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;

namespace Prodavnica
{
    public enum Vrsta { Voce, Sok }
    public static class Prodavnica
    {
        static Dictionary<string, Artikal> listaArtikala = new Dictionary<string, Artikal>();       

        public static int BrojArtikala(Vrsta vrsta)
        {
            int broj = 0;

            if (vrsta.Equals(Vrsta.Voce))
            {
                foreach (Artikal a in listaArtikala.Values)
                {
                    if (a is Voce)
                        broj++;
                }
            }
            else if (vrsta.Equals(Vrsta.Sok))
            {
                foreach (Artikal a in listaArtikala.Values)
                {
                    if (a is Sok)
                        broj++;
                }
            }
            return broj;
        }

        public static void UkupnaVrednost(out double vrednost)
        {
            vrednost = 0;
            foreach (KeyValuePair<string, Artikal> kvp in listaArtikala)
            {
                vrednost += kvp.Value.Cena;
            }

        }

        public static void DodajArtikal(Artikal a)
        {
            if (!listaArtikala.ContainsKey(a.IdArtikla))
            {
                listaArtikala.Add(a.IdArtikla, a);
            }
        }

        public static bool ObrisiArtikal(string id)
        {
            if (listaArtikala.ContainsKey(id))
            {
                listaArtikala.Remove(id);
                return true;
            }
            return false;
        }

        public static void UpisiArtikleUFajl(string imeFajla)
        {
            try
            {
                using (FileStream izlazniStream = File.Create(imeFajla))
                {
                    BinaryFormatter formatter = new BinaryFormatter();
                    formatter.Serialize(izlazniStream, listaArtikala.Values.ToList());

                    Console.WriteLine("Uspešno serijalizovani artikli");
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("Problem pri serijalizaciji objekta. Poruka : " + e.Message);
            }
        }

        public static List<Artikal> ProcitajArtikalIzFajla(string imeFajla)
        {
            try
            {
                using (FileStream ulazniStream = File.OpenRead(imeFajla))
                {
                    BinaryFormatter formatter = new BinaryFormatter();
                    List<Artikal> artikli = (List<Artikal>)formatter.Deserialize(ulazniStream);
                    return artikli;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("Problem pri deserijalizaciji objekta. Poruka : " + e.Message);
                return null;
            }
        }



        public static string SviArtikli()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("ARTIKLI U PRODAVNICI :");
            foreach (Artikal a in listaArtikala.Values)
            {
                sb.AppendLine(a.ToString());
            }
            return sb.ToString();
        }
    }
}
