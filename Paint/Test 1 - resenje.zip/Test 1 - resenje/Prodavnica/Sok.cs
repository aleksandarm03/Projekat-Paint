﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prodavnica
{
    [Serializable]
    public class Sok : Artikal
    {
        string proizvodjac;
        bool gazirani;

        public Sok() : base()
        {

        }

        public Sok(string naziv, string id, double cena, string proizvodjac, bool gazirani)
            : base(naziv, id, cena)
        {
            Proizvodjac = proizvodjac;
            Gazirani = gazirani;
        }

        public string Proizvodjac
        {
            get { return proizvodjac; }
            set { proizvodjac = value; }
        }

        public bool Gazirani
        {
            get { return gazirani; }
            set { gazirani = value; }
        }

        public override string ToString()
        {
            return String.Format("Sok sa {0} sa nazivom {1} ima cenu {2} dinara. {3}"
                , base.IdArtikla, Naziv, Cena, gazirani ? "Gazirano pice" : "Negazirano pice");

        }
    }
}
