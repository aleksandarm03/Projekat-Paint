﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prodavnica
{
    [Serializable]
    class Voce : Artikal
    {
        string zemljaPorekla;

        public Voce():base()
        {
            zemljaPorekla = "";
        }

        public Voce(string naziv, string id, double cena, string zemljaPorekla)
            :base(naziv,id,cena)
        {
            ZemljaPorekla = zemljaPorekla;
        }

        public string ZemljaPorekla
        {
            get { return zemljaPorekla; }
            set { zemljaPorekla = value; }
        }

        public override string ToString()
        {
            return String.Format("Voce sa {0} sa nazivom {1} ima cenu {2} dinara. Zemlja porekla je {3}"
                , base.IdArtikla, Naziv, Cena, zemljaPorekla);

        }
    }
}
