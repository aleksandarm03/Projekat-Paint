﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prodavnica
{
    class Program
    {
        static void Main(string[] args)
        {
            
            Sok s1 = new Sok("Fanta", "idF", 109,"proizvodjac 1", true);
            Sok s2 = new Sok("CocaCola", "idCC", 119, "proizvodjac 1", true);
            Sok s3 = new Sok("Next", "idN", 132, "proizvodjac 2", false);
            Sok s4 = new Sok("Cocta", "idC", 98, "proizvodjac 2", true);
            Sok s5 = new Sok("LaVita", "idLV", 105, "proizvodjac 2", false);
            Sok s6 = new Sok("Sprite", "idSp", 108, "proizvodjac 3", true);
            Sok s7 = new Sok("Fruvita", "idFr", 152, "proizvodjac 4", false);

            Prodavnica.DodajArtikal(s1);
            Prodavnica.DodajArtikal(s2);
            Prodavnica.DodajArtikal(s3);
            Prodavnica.DodajArtikal(s4);
            Prodavnica.DodajArtikal(s5);
            Prodavnica.DodajArtikal(s6);
            Prodavnica.DodajArtikal(s7);

            Voce v1 = new Voce("Ananas", "idA", 120, "Brazil");
            Voce v2 = new Voce("Banana", "idB", 100, "Brazil");
            Voce v3 = new Voce("Kivi", "idK", 99, "Francuska");
            Voce v4 = new Voce("Mango", "idM", 352, "Indija");
            Voce v5 = new Voce("Kokos", "idKo", 1020, "Meksiko");
            Voce v6 = new Voce("Kumkvat", "idKK", 850, "Kina");
            Voce v7 = new Voce("Papaja", "idP", 950, "Meksiko");

            Prodavnica.DodajArtikal(v1);
            Prodavnica.DodajArtikal(v2);
            Prodavnica.DodajArtikal(v3);
            Prodavnica.DodajArtikal(v4);
            Prodavnica.DodajArtikal(v5);
            Prodavnica.DodajArtikal(v6);
            Prodavnica.DodajArtikal(v7);

            Prodavnica.UpisiArtikleUFajl("artikli");

            Prodavnica.ObrisiArtikal("idSp");
            Prodavnica.ObrisiArtikal("idCC");

            Console.WriteLine(Prodavnica.SviArtikli());

            double vrednost;
            Prodavnica.UkupnaVrednost(out vrednost);
            Console.WriteLine("U prodavnici ima {0} sokova i {1} voca, a ukupna vrednost artikala je {2}",
                 Prodavnica.BrojArtikala(Vrsta.Sok), Prodavnica.BrojArtikala(Vrsta.Voce), vrednost);

            List<Artikal> artikli = Prodavnica.ProcitajArtikalIzFajla("artikli");

            Console.WriteLine("Artikli iz fajla");
            foreach (Artikal a in artikli)
            {
                Console.WriteLine(a);
            }
            
        }
    }
}
