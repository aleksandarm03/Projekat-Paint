﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prodavnica
{
    [Serializable]
    public class Artikal
    {
        string naziv, idArtikla;
        double cena;

        public Artikal()
        {
            Naziv = "";
            idArtikla = "";
            cena = 0;                

        }

        public Artikal(string naziv, string id, double cena)
        {
            Naziv = naziv;
            IdArtikla = id;
            Cena = cena;
        }

        public string Naziv
        {
            get { return naziv; }
            set { naziv = value; }
        }

        public string IdArtikla
        {
            get { return idArtikla; }
            set { idArtikla = value; }
        }

        public double Cena
        {
            get { return cena; }
            set { cena = value; }
        }

        public override string ToString()
        {
            return String.Format("Artikal sa {0} sa nazivom {1} ima cenu {2} dinara.", idArtikla,naziv,cena);
        }
    }
}
